Name: Xiaoyu Chen

Section: COP3503C — Summer 2025

UFL Email: xiaoyu.chen1@ufl.edu

System: Windows 10 64-bit

Compiler: g++ (C++11 standard)

SFML version: SFML 2.5.1

IDE: CLion 2024.3.5

Other notes: None

